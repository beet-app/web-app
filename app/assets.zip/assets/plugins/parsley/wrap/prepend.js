/*!
* @@name
* @@author
* Version @@version - built @@timestamp
* @@license Licensed
*
*/

!(function($) {
